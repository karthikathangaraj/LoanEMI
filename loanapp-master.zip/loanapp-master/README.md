# django-loanapp
A simple Django web app to calculate the EMI for a given loan amount.
